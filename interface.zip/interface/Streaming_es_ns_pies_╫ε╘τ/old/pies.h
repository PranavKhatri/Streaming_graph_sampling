#include "stdafx.h"

using namespace std;

class pies
{
public:
  pies(string inputFile , int sampleSize , string outputFile);
	~pies(void);

	string inputFile;
	int size;
	string outputFile;

	
	map<int64_t,int> VSdegree;
	map<int,int> degreeMap;
	multimap<int64_t,int64_t> ES;


	void process();
	void updateDegreeMap(int , int);
	void dropNode();

	void delEdge(int64_t);
	void saveSampleGraph();
};