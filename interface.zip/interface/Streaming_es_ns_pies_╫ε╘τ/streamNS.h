#include "stdafx.h"

using namespace std;

class streamNS
{
public:
	streamNS( string inputFile , int sampleSize , string outputFile );
	~streamNS(void);

	string inputFile;
	int size;
	string outputFile;

	map<uint64_t,uint64_t> VShash; 
	map<uint64_t,int> VSdegree;
	multimap<uint64_t,uint64_t> ES;

  void delEdge_process(string line, int salt);
  void addEdge_process(string line, int salt);
	void process();
 
	uint64_t hash64( uint64_t , int );
	void delEdge( uint64_t , int );
	void saveSampleGraph();
};


