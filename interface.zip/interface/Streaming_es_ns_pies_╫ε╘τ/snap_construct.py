import os
import time
import copy

#######################################################
#function: build a edge snapshot based on snapshot file
#######################################################
def build_snapshot(fp_snapshot):
    snapshot = [];
    for line in fp_snapshot:
        snapshot.append(line)
    return snapshot

if __name__ == '__main__':

    current_snapshot = []


    snapdir = "./old_pies_snapshot/"
     
    stream_filename = "collection.graph"
    fp_stream = open(stream_filename, 'r')


    for line in fp_stream:
        if ((line[0] >= '0') and (line[0] <= '9')):
            current_snapshot.append(line)
        elif (line[0] == '!'):
            delete_item = line[2:]
            current_snapshot.remove(delete_item)
        else:
            snap_filename = line.strip('\n')
            fp_snapshot = open(snap_filename, 'r')
            original_snapshot = build_snapshot(fp_snapshot)
            for i in current_snapshot:
                if (i not in original_snapshot):
                    print snap_filename + "is not well constructed!\n"
                    break
         
           
            
