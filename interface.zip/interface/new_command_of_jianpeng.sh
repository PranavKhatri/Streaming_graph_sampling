#add pies_random and advanced
# for k in $( seq 0 4 )
# do
# ##### enronY 
#    ./pies_new 151 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronY_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_enronY_result_${k}/
#    ./pies_old 151 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronY_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_enronY_result_${k}/
#    ./pies_isolated_first 151 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronY_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_enronY_result_${k}/
#    ./streamNS 151 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronY_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_enronY_result_${k}/
#    ./streamES 151 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronY_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_enronY_result_${k}/
#    ./pies_random 151 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronY_u_45/collection.graph ../powlaw_degree_benchmark_results/random_pies_enronY_result_${k}/
#    ./pies_advanced 151 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronY_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_enronY_result_${k}/
# done
for k in $( seq 0 4 )
do
##### RealityY
   # ./pies_new 6809 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_realityY_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_realityY_result_${k}/
   # ./pies_old 6809 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_realityY_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_realityY_result_${k}/
   # ./pies_isolated_first 6809 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_realityY_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_realityY_result_${k}/
   # ./streamNS 6809 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_realityY_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_realityY_result_${k}/
   # ./streamES 6809 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_realityY_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_realityY_result_${k}/
   ./pies_random 6809 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_realityY_u_45/collection.graph ../powlaw_degree_benchmark_results/random_pies_realityY_result_${k}/
   ./pies_advanced 6809 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_realityY_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_realityY_result_${k}/
done
for k in $( seq 0 4 )
do
##### email_Eu_core
   # ./pies_new 986 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_email_Eu_core_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_email_Eu_core_result_${k}/
   # ./pies_old 986 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_email_Eu_core_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_email_Eu_core_result_${k}/
   # ./pies_isolated_first 986 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_email_Eu_core_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_email_Eu_core_result_${k}/
   # ./streamNS 986 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_email_Eu_core_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_email_Eu_core_result_${k}/
   # ./streamES 986 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_email_Eu_core_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_email_Eu_core_result_${k}/
   ./pies_random 986 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_email_Eu_core_u_45/collection.graph ../powlaw_degree_benchmark_results/random_pies_email_Eu_core_result_${k}/
   ./pies_advanced 986 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_email_Eu_core_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_email_Eu_core_result_${k}/
done
for k in $( seq 0 4 )
do
##### ColleageMsg
   # ./pies_new 1899 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_ColleageMsg_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_ColleageMsg_result_${k}/
   # ./pies_old 1899 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_ColleageMsg_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_ColleageMsg_result_${k}/
   # ./pies_isolated_first 1899 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_ColleageMsg_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_ColleageMsg_result_${k}/
   # ./streamNS 1899 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_ColleageMsg_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_ColleageMsg_result_${k}/
   # ./streamES 1899 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_ColleageMsg_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_ColleageMsg_result_${k}/
   ./pies_random 1899 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_ColleageMsg_u_45/collection.graph ../powlaw_degree_benchmark_results/random_pies_ColleageMsg_result_${k}/
   ./pies_advanced 1899 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_ColleageMsg_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_ColleageMsg_result_${k}/
done
########################
###Big graph############
########################
########################
# for k in $( seq 0 2 )
# do
# #### slashdotY 
#   ./pies_new 6727 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_slashdotY_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_slashdotY_result_${k}/
#   ./pies_old 6727 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_slashdotY_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_slashdotY_result_${k}/
#   ./pies_isolated_first  6727 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_slashdotY_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_slashdotY_result_${k}/
#   ./streamNS  6727 0.2   ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_slashdotY_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_slashdotY_result_${k}/
#   ./streamES  6727 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_slashdotY_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_slashdotY_result_${k}/
#   ./pies_random  6727 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_slashdotY_u_45/collection.graph ../powlaw_degree_benchmark_results/random_pies_slashdotY_result_${k}/
#   ./pies_advanced 6727 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_slashdotY_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_slashdotY_result_${k}/
# done
# for k in $( seq 0 2 )
# do
# #### facebookY
#   ./pies_new 46952 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_facebookY_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_facebookY_result_${k}/
#   ./pies_old 46952 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_facebookY_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_facebookY_result_${k}/
#   ./pies_isolated_first 46952 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_facebookY_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_facebookY_result_${k}/
#   ./streamNS 46952 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_facebookY_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_facebookY_result_${k}/
#   ./streamES 46952 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_facebookY_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_facebookY_result_${k}/
#   ./pies_random 46952 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_facebookY_u_45/collection.graph ../powlaw_degree_benchmark_results/random_pies_facebookY_result_${k}/
#   ./pies_advanced 46952 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_facebookY_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_facebookY_result_${k}/
# done
# for k in $( seq 0 2 )
# do
# #### SMS_A
#   ./pies_new 44430 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_SMS_A_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_SMS_A_result_${k}/
#   ./pies_old 44430 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_SMS_A_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_SMS_A_result_${k}/
#   ./pies_isolated_first 44430 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_SMS_A_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_SMS_A_result_${k}/
#   ./streamNS 44430 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_SMS_A_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_SMS_A_result_${k}/
#   ./streamES 44430 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_SMS_A_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_SMS_A_result_${k}/
#   ./pies_random 44430 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_SMS_A_u_45/collection.graph ../powlaw_degree_benchmark_results/random_pies_SMS_A_result_${k}/
#   ./pies_advanced 44430 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_SMS_A_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_SMS_A_result_${k}/
# done
# for k in $( seq 0 2 )
# do
# #### sx_stackoverflow
#   ./pies_new 2601977 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_sx_stackoverflow_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_sx_stackoverflow_result_${k}/
#   ./pies_old 2601977 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_sx_stackoverflow_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_sx_stackoverflow_result_${k}/
#   ./pies_isolated_first 2601977 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_sx_stackoverflow_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_sx_stackoverflow_result_${k}/
#   ./streamNS 2601977 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_sx_stackoverflow_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_sx_stackoverflow_result_${k}/
#   ./streamES 2601977 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_sx_stackoverflow_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_sx_stackoverflow_result_${k}/
#   ./pies_random 2601977 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_sx_stackoverflow_u_45/collection.graph ../powlaw_degree_benchmark_results/random_pies_sx_stackoverflow_result_${k}/
#   ./pies_advanced 2601977 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_sx_stackoverflow_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_sx_stackoverflow_result_${k}/
# done
# for k in $( seq 0 2 )
# do
# #### wikitalk
#   ./pies_new 1091742 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_wikitalk_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_wikitalk_result_${k}/
#   ./pies_old 1091742 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_wikitalk_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_wikitalk_result_${k}/
#   ./pies_isolated_first 1091742 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_wikitalk_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_wikitalk_result_${k}/
#   ./streamNS 1091742 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_wikitalk_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_wikitalk_result_${k}/
#   ./streamES 1091742 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_wikitalk_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_wikitalk_result_${k}/
#   ./pies_random 1091742 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_wikitalk_u_45/collection.graph ../powlaw_degree_benchmark_results/random_pies_wikitalk_result_${k}/
#   ./pies_advanced 1091742 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_wikitalk_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_wikitalk_result_${k}/
# done

