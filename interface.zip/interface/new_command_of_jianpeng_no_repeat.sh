#dataset that only consider the interval of time span including the edge deletion.
##### enron
#./pies_new 120 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enron_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_enron_result/
#./pies_old 120 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enron_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_enron_result/
#./pies_isolated_first 120 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enron_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_enron_result/
#./streamNS 120 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enron_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_enron_result/
#./streamES 120 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enron_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_enron_result/
#./pies_advanced 120 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enron_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_enron_result/
##### slashdot 
#./pies_new 6727 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_slashdot_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_slashdot_result/
#./pies_old 6727 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_slashdot_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_slashdot_result/
#./pies_isolated_first  6727 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_slashdot_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_slashdot_result/
#./streamNS  6727 0.2   ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_slashdot_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_slashdot_result/
#./streamES  6727 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_slashdot_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_slashdot_result/
#./pies_advanced 6727 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_slashdot_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_slashdot_result/
##### reality
#./pies_new 1350 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_reality_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_reality_result/
#./pies_old 1350 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_reality_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_reality_result/
#./pies_isolated_first 1350 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_reality_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_reality_result/
#./streamNS 1350 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_reality_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_reality_result/
#./streamES 1350 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_reality_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_reality_result/
#./pies_advanced 1350 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_reality_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_reality_result/
##### facebook
#./pies_new 13586 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_facebook_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_facebook_result/
#./pies_old 13586 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_facebook_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_facebook_result/
#./pies_isolated_first 13586 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_facebook_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_facebook_result/
#./streamNS 13586 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_facebook_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_facebook_result/
#./streamES 13586 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_facebook_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_facebook_result/
#./pies_advanced 13586 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_facebook_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_facebook_result/
#
#
#new datasets
##### enronY
#./pies_new 151 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronY_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_enronY_result/
#./pies_old 151 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronY_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_enronY_result/
#./pies_isolated_first 151 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronY_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_enronY_result/
#./streamNS 151 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronY_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_enronY_result/
#./streamES 151 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronY_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_enronY_result/
#./pies_advanced 151 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronY_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_enronY_result/
##### RealityY
#./pies_new 6809 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_realityY_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_realityY_result/
#./pies_old 6809 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_realityY_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_realityY_result/
#./pies_isolated_first 6809 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_realityY_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_realityY_result/
#./streamNS 6809 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_realityY_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_realityY_result/
#./streamES 6809 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_realityY_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_realityY_result/
#./pies_advanced 6809 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_realityY_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_realityY_result/
##### slashdotY 
#./pies_new 6727 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_slashdotY_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_slashdotY_result/
#./pies_old 6727 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_slashdotY_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_slashdotY_result/
#./pies_isolated_first  6727 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_slashdotY_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_slashdotY_result/
#./streamNS  6727 0.2   ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_slashdotY_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_slashdotY_result/
#./streamES  6727 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_slashdotY_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_slashdotY_result/
#./pies_advanced 6727 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_slashdotY_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_slashdotY_result/
##### facebookY
#./pies_new 46952 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_facebookY_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_facebookY_result/
#./pies_old 46952 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_facebookY_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_facebookY_result/
#./pies_isolated_first 46952 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_facebookY_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_facebookY_result/
#./streamNS 46952 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_facebookY_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_facebookY_result/
#./streamES 46952 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_facebookY_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_facebookY_result/
#./pies_advanced 46952 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_facebookY_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_facebookY_result/
##### email_Eu_core
#./pies_new 986 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_email_Eu_core_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_email_Eu_core_result/
#./pies_old 986 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_email_Eu_core_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_email_Eu_core_result/
#./pies_isolated_first 986 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_email_Eu_core_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_email_Eu_core_result/
#./streamNS 986 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_email_Eu_core_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_email_Eu_core_result/
#./streamES 986 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_email_Eu_core_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_email_Eu_core_result/
#./pies_advanced 986 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_email_Eu_core_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_email_Eu_core_result/
##### ColleageMsg
#./pies_new 1899 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_ColleageMsg_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_ColleageMsg_result/
#./pies_old 1899 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_ColleageMsg_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_ColleageMsg_result/
#./pies_isolated_first 1899 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_ColleageMsg_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_ColleageMsg_result/
#./streamNS 1899 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_ColleageMsg_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_ColleageMsg_result/
#./streamES 1899 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_ColleageMsg_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_ColleageMsg_result/
#./pies_advanced 1899 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_ColleageMsg_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_ColleageMsg_result/
##### SMS_A
#./pies_new 44430 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_SMS_A_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_SMS_A_result/
#./pies_old 44430 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_SMS_A_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_SMS_A_result/
#./pies_isolated_first 44430 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_SMS_A_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_SMS_A_result/
#./streamNS 44430 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_SMS_A_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_SMS_A_result/
#./streamES 44430 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_SMS_A_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_SMS_A_result/
#./pies_advanced 44430 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_SMS_A_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_SMS_A_result/
##### sx_stackoverflow
./pies_new 2601977 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_sx_stackoverflow_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_sx_stackoverflow_result/
./pies_old 2601977 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_sx_stackoverflow_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_sx_stackoverflow_result/
./pies_isolated_first 2601977 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_sx_stackoverflow_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_sx_stackoverflow_result/
./streamNS 2601977 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_sx_stackoverflow_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_sx_stackoverflow_result/
./streamES 2601977 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_sx_stackoverflow_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_sx_stackoverflow_result/
#./pies_advanced 2601977 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_sx_stackoverflow_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_sx_stackoverflow_result/
##### wikitalk
./pies_new 1091742 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_wikitalk_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_wikitalk_result/
./pies_old 1091742 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_wikitalk_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_wikitalk_result/
./pies_isolated_first 1091742 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_wikitalk_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_wikitalk_result/
./streamNS 1091742 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_wikitalk_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_wikitalk_result/
./streamES 1091742 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_wikitalk_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_wikitalk_result/
#./pies_advanced 1091742 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_wikitalk_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_wikitalk_result/
