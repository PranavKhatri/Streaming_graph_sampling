./pies_advanced 128 0.5 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_mergesplit_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_mergesplit_result/
./pies_new 128 0.5 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_mergesplit_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_mergesplit_result/
./pies_old 128 0.5 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_mergesplit_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_mergesplit_result/
./pies_isolated_first 128 0.5 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_mergesplit_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_mergesplit_result/
./streamNS 128 0.5 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_mergesplit_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_mergesplit_result/
./streamES 128 0.5 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_mergesplit_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_mergesplit_result/


#################################################################
#################################################################
#another benchmark
#################################################################
./pies_new 128 0.5 ../original_snapshot_merge/collection.graph ../new_pies_merge_result/
./pies_old 128 0.5 ../original_snapshot_merge/collection.graph ../old_pies_merge_result/
./pies_isolated_first 128 0.5 ../original_snapshot_merge/collection.graph ../isolated_first_pies_merge_result/
./streamNS 128 0.5 ../original_snapshot_merge/collection.graph ../streamNS_merge_result/
./streamES 128 0.5 ../original_snapshot_merge/collection.graph ../streamES_merge_result/


./pies_new 128 0.5 ../original_snapshot_grow/collection.graph ../new_pies_grow_result/
./pies_old 128 0.5 ../original_snapshot_grow/collection.graph ../old_pies_grow_result/
./pies_isolated_first 128 0.5 ../original_snapshot_grow/collection.graph ../isolated_first_pies_grow_result/
./streamNS 128 0.5 ../original_snapshot_grow/collection.graph ../streamNS_grow_result/
./streamES 128 0.5 ../original_snapshot_grow/collection.graph ../streamES_grow_result/

./pies_new 128 0.5 ../original_snapshot_mixed/collection.graph ../new_pies_mixed_result/
./pies_old 128 0.5 ../original_snapshot_mixed/collection.graph ../old_pies_mixed_result/
./pies_isolated_first 128 0.5 ../original_snapshot_mixed/collection.graph ../isolated_first_pies_mixed_result/
./streamNS 128 0.5 ../original_snapshot_mixed/collection.graph ../streamNS_mixed_result/
./streamES 128 0.5 ../original_snapshot_mixed/collection.graph ../streamES_mixed_result/
