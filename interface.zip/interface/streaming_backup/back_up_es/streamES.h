#include "stdafx.h"


using namespace std;

class streamES
{
public:
	streamES(string inFile , int originSize, float sampleRatio , string outFile);
	~streamES();

	string inputFile;
	int size;
  float ratio;
	string outputFile;

	map< uint64_t, map<uint64_t,uint64_t> > EShash;
	map< uint64_t, int > VSdegree;

  void delEdge_process(string line, int salt);
  void addEdge_process(string line, int salt);
	void process();
 
	uint64_t hash64( uint64_t , uint64_t , int );
	void delEdge();
	void saveSampleGraph();

};

	
