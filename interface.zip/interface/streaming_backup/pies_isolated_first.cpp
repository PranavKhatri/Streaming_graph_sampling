#include "stdafx.h"
#include "stdio.h"
#include "pies.h"
#include "time.h"

#include "string.h"
#include <sys/stat.h>
#include <sys/types.h>

using namespace std;

pies::pies( string inFile , int originSize, float sampleRatio , string outFile )
{
	inputFile = inFile;
  ratio = sampleRatio;
	size = (int)(originSize * sampleRatio);
	outputFile = outFile;
  
  top_forbidden_stack = 0;
}

pies::~pies()
{
}

void pies::delEdge_process(string line, int *t)
{
  char symbol = ' ';
  int64_t from=0;
	int64_t to=0;
 
  sscanf(line.c_str(),"%c %ld %ld",&symbol,&from,&to);
  
  //printf("delete edge:(%d, %d)\n", from, to);
 
  multimap<int64_t,int64_t>::iterator position = ES.lower_bound(from);
	multimap<int64_t,int64_t>::iterator upper = ES.upper_bound(from);
  while( position != upper)
  {
    if( position->second == to)
    {
      ES.erase(position);
      break;
    }
    position++;
  }
  if(position == upper) //this edge was not sampled into edgelist, the delEdge_process should not go on
  {
    //printf("this edge was not be sampled, we need not to delete it\n");
    return;
  }
  
  position = ES.lower_bound(to);
	upper = ES.upper_bound(to);
  while( position != upper)
  {
    if( position->second == from)
    {
      ES.erase(position);
      break;
    }
    position++;
  }

  map<int64_t,int>::iterator fromVSdegree = VSdegree.find(from);
  map<int64_t,int>::iterator toVSdegree =  VSdegree.find(to);  
  if(fromVSdegree != VSdegree.end())
  {
    VSdegree[from]--;
    updateDegreeMap(VSdegree[from],1);
    updateDegreeMap(VSdegree[from]+1,-1);
    if(VSdegree[from] == 0)
    {
      //printf("the degree of node '%d' is 0, this node should be removed\n", from);
      VSdegree.erase(fromVSdegree);
    }
  }
  if(toVSdegree != VSdegree.end())
  {
    VSdegree[to]--;
    updateDegreeMap(VSdegree[to],1);
    updateDegreeMap(VSdegree[to]+1,-1);
    if(VSdegree[to] == 0)
    {
      //printf("the degree of node '%d' is 0, this node should be removed\n", to);
      VSdegree.erase(toVSdegree);
    }
  }
  
  return;
}

void pies::addEdge_process(string line, int *t)
{

	int64_t from=0;
	int64_t to=0;
 
	float pe = 0;
	float r = 0;
		
  sscanf(line.c_str(),"%ld %ld",&from,&to);
  //printf("add edge:(%d, %d)\n", from, to);
  
  //push from and to into forbidden 
  forbidden_stack[top_forbidden_stack] = from;
  top_forbidden_stack++;
  forbidden_stack[top_forbidden_stack] = to;   
  top_forbidden_stack++;
    

  if ( VSdegree.size() < size )
  {
    //printf("sample size has not been reaches, so sample this edge directly...\n");
      
    if( VSdegree.find(from) == VSdegree.end() )
    {
		  VSdegree.insert( pair<int64_t,int>(from,0) );
    }
		if( VSdegree.find(to) == VSdegree.end() )
		{
		  VSdegree.insert( pair<int64_t,int>(to,0) );
		}

    ES.insert( pair<int64_t,int64_t>(from,to) );
    ES.insert( pair<int64_t,int64_t>(to,from) );
     
    VSdegree[from]++;
    updateDegreeMap(VSdegree[from],1);
    updateDegreeMap(VSdegree[from]-1,-1);

    VSdegree[to]++;
    updateDegreeMap(VSdegree[to],1);
    updateDegreeMap(VSdegree[to]-1,-1);
				    
  }
  else
  {	
    //printf("sample size has been reaches, so we decide whether to replace it on probability...\n");
    
    bool flag = false; //false��edge should not be sampled; true: edge should be sampled
          
    pe = ES.size() / ( (float)(*t) * 2.0 );
		r = rand() / double(RAND_MAX+1.0);
    
      
    if ( r <= pe )
    {
      flag = true;
    }    
    if ((VSdegree.find(from) == VSdegree.end())
    && ( VSdegree.find(to) == VSdegree.end()))
    {
      flag = true;
    }
    
    if ( flag == true )
    {
      //printf("good luck, add it\n");
      if ( VSdegree.find(from) == VSdegree.end() )
      {
		    dropNode();
				VSdegree.insert(pair<int64_t,int>(from,0));
      }
      if ( VSdegree.find(to) == VSdegree.end() )
      {
				dropNode();
				VSdegree.insert(pair<int64_t,int>(to,0));
      }
    }
    else
    {
      //printf("bad luck, not to add it\n");
    }
    
    if ( VSdegree.find(from) != VSdegree.end() && VSdegree.find(to) != VSdegree.end() )
    {
      //printf("now we can add it\n");
      
      ES.insert( pair<int64_t,int64_t>(from,to) );
      ES.insert( pair<int64_t,int64_t>(to,from) );

      VSdegree[from]++;
      updateDegreeMap(VSdegree[from],1);
      updateDegreeMap(VSdegree[from]-1,-1);

      VSdegree[to]++;
      updateDegreeMap(VSdegree[to],1);
      updateDegreeMap(VSdegree[to]-1,-1);
    }
    
    
  }
  
  //pull from and to out of forbidden stack
  top_forbidden_stack = top_forbidden_stack - 2;
    
}

void pies::process()
{
	ifstream ifs(inputFile.c_str());
	if( !ifs.is_open() )
	{
		cout<<"Error opening file";
		exit(1);
	}

	cout<<"sampling......"<<endl;
	string line;

	int t = 1;
	unsigned long seed = 0;

	while( getline( ifs,line ))
	{	
    //printf("t = %d\n", t);

		seed += (unsigned)time(NULL)%1000;
		srand(seed%100000000);
		
    if((line[0] >= '0') && (line[0] <= '9'))
    {
		  addEdge_process(line, &t);
      
      //printf("VSdegree size: %d\n", VSdegree.size());
      //printf("ES size %d\n", ES.size());

    }
    else if(line[0] == '!')
    {
      delEdge_process(line, &t);
      
      //printf("VSdegree size: %d\n", VSdegree.size());
      //printf("ES size %d\n", ES.size());
      
    }
    else
    {
      string filename(line);
    
      char snapshot_dir[128] = "../new_isolated_pies_snapshot/";
      char buf[16];
      sprintf(buf, "%f", ratio);
      strcat(snapshot_dir, buf);
      strcat(snapshot_dir, "/");
      if (access(snapshot_dir, 6)==-1)
      {
          printf("create!\n");
          mkdir(snapshot_dir, S_IRWXU);
      }
      
      string dir(snapshot_dir);  
      string filepath = dir + filename;
      
      int i;
       
      cout << "snapshot " << filename << "is completed" << endl;
	    cout<<"VS COUNT: "<<VSdegree.size()<<"  "<<" ES COUNT: "<<ES.size()<<endl;            
           
      ofstream out(filepath.c_str());
	    if ( ! out.is_open() )
	    {
		      cout<<"Error opening file"<<endl;
		      exit(1);
	    }

      multimap<int64_t,int64_t>::const_iterator it;
	    for ( it = ES.begin(); it != ES.end() ; it++ )
	    {
         if (it->first < it->second)
         {
           out<<it->first<<" "<<it->second<<endl;
         }
         if (it->first == it->second)
         {
           printf("impossible!\n");
         }
	    }
      out.close();
           
    }

    //////////////////////////////////////
    seekZeroDegreeNode();
    ///////////////////////////////////////
    

		t++;

	}
}

void pies::updateDegreeMap( int degree , int para )
{
	map<int,int>::iterator mt;

	if (degree <= 0)
	{
		return;
	}

	if (para > 0)
	{
		if ((mt = degreeMap.find(degree)) == degreeMap.end())
		{   
			degreeMap.insert(pair<int,int>(degree,para));
		}
		else
		{   
			mt->second += para;
		}
	}
	else if (para < 0)
	{
		mt = degreeMap.find(degree);	

		if (mt->second + para <= 0)
		{
			degreeMap.erase(mt);
		}
		else
		{
			mt->second += para;
		}
	}
}
	
	

void pies::dropNode()
{
	double max = 0;
	map<int,int>::iterator it;
	for ( it = degreeMap.begin() ; it != degreeMap.end() ; it++ )
	{
		max = max + (it->second) * float(1.0) / it->first;
	}
	
	unsigned long seed = (unsigned long)max;
	srand(seed);	

	float randomValue = rand() % ( size + 1 );

	map<int64_t,int>::iterator itVSdegree;
	int64_t rmVertex=0;
	
	float addValue = 0;
	float tempValue = 0;

	for ( itVSdegree = VSdegree.begin() ; itVSdegree != VSdegree.end() ; itVSdegree++ )
	{

		//tempValue = size * float(1.0)/( itVSdegree->second * max);	 
		tempValue = 1.0;
    addValue += tempValue;
    
    if ( addValue >= randomValue )
		{
      rmVertex = itVSdegree -> first;
        
      if ( isInForbiddenStack(rmVertex) == true )
      {
        continue;
      }

			//add by zhukaijie, to check if the degree of rmVertex is larger than that of its neighbors
			multimap<int64_t,int64_t>::iterator position = ES.lower_bound(rmVertex);
      multimap<int64_t,int64_t>::iterator upper = ES.upper_bound(rmVertex);
			int64_t neighbor = 0; //record the neighbor of rmVertex
			int64_t tempVertex = rmVertex;  //once rmVertex is the centre or hub, we remove tempVertex rather than rmVertex
			int tempdegree = VSdegree[rmVertex]; 
		  map<int64_t,int>::iterator tempVSdegree;
      
      while( position != upper ) //retrieve all the edges contain rmVertex so that we could get all its neighbors
			{
				neighbor = position->second;
        if( VSdegree[rmVertex] < VSdegree[neighbor] ) //degree of rmVertex is smaller than that of one of its neighbor, so it could not be a centre of community or hub
				{
					break;
				}
				else //degree of rmVertex is smaller than that of one of its neighbor
				{	
					if( VSdegree[neighbor] <= tempdegree ) //we need to record the neighbor with the smallest degree
					{
						tempVertex = neighbor;
						tempdegree = VSdegree[neighbor];
					}
				}
				position++;
			}
			
      
			if( position == upper ) //the degree of rmVertex is larger than that of all its neighbors. So we should keep it and rm tempVertex, the neighbor with the smallestdegree instead
			{
				//printf( "node %d is a key node with degree: %d, we could remove its neighbor %d with the smallest degree: %d\n", rmVertex, VSdegree[rmVertex], tempVertex, tempdegree);
			
				tempVSdegree = VSdegree.find(tempVertex);
				
				updateDegreeMap( tempVSdegree->second , -1 );
				VSdegree.erase( tempVSdegree);
				delEdge( tempVertex );
			}
			else
			{
				//printf( "node %d is not a key node with degree %d, we could remove it directly\n", rmVertex, VSdegree[rmVertex]);
				
				updateDegreeMap( itVSdegree->second , -1 );
				VSdegree.erase( itVSdegree );
				delEdge( rmVertex );
			}
			
			break;
		}
	}

	//cout<<"Node "<<rmVertex<<" is deleted "<<endl;
}
void pies::delEdge( int64_t node )
{
	multimap<int64_t,int64_t>::iterator itES;
	map<int64_t,int>::iterator itVSdegree;

	multimap<int64_t,int64_t>::iterator end;
	map<int64_t,int>::iterator endVSdegree;

	multimap<int64_t,int64_t>::iterator position = ES.lower_bound(node);
	multimap<int64_t,int64_t>::iterator upper = ES.upper_bound(node);

	multimap<int64_t,int64_t>::iterator position2;
	multimap<int64_t,int64_t>::iterator upper2;

	while( position != upper )
	{
		position2 = ES.lower_bound(position->second);
		upper2 = ES.upper_bound(position->second);
		while( position2 != upper2 )
		{
			if ( position2->second == node && position2->first != node)
			{
				itVSdegree = VSdegree.find( position2->first );
				itVSdegree->second -= 1;
				
				updateDegreeMap( itVSdegree->second , 1 );
				updateDegreeMap( (itVSdegree->second) + 1 , -1 );

				if ( itVSdegree->second <= 0 )
				{
          if ( isInForbiddenStack(itVSdegree->first) == false ) //
          {
					  VSdegree.erase( itVSdegree );
          }
				}

				if ( position2 == upper )
				{
					
					multimap<int64_t,int64_t>::iterator temp;
					temp = position2;
					temp++;
					upper = temp;
					ES.erase(position2);
				}
				else
				{
					ES.erase(position2);
				}

				break;
			}
		position2++;
		}
	position++;
	}
	ES.erase(node);
}

void pies::saveSampleGraph()
{
	cout<<"VS COUNT: "<<VSdegree.size()<<"  "<<" ES COUNT: "<<ES.size()<<endl;

	multimap<int64_t,int64_t>::const_iterator it;
	ofstream out(outputFile.c_str());
	if ( ! out.is_open() )
	{
		cout<<"Error opening file"<<endl;
		exit(1);
	}

	for ( it = ES.begin(); it != ES.end() ; it++ )
	{
		out<<it->first<<" "<<it->second<<endl;
	}

	out.close();
}

void pies::seekZeroDegreeNode()
{
  map<int64_t,int>::iterator itVSdegree;
	for ( itVSdegree = VSdegree.begin() ; itVSdegree != VSdegree.end() ; itVSdegree++ )
  {
    if(itVSdegree->second <= 0)
    {
      printf("there is a node %d with degree %d, it should be erased\n", itVSdegree->first, itVSdegree->second);
//      sleep(1000);
    }
  }
}

bool pies::isInForbiddenStack(int64_t node)
{
  for(int i = 0; i < top_forbidden_stack; i++)
  {
    //printf("forbidden_stack[%d] = %d, rmVertex = %d\n", i, forbidden_stack[i], rmVertex);
    if(forbidden_stack[i] == node)
    {   
      return true;
    }
  }
  return false;  
}

int main(int argc, char* argv[])
{
	string inputFile("../original_snapshot_20w/collection.graph");
	string outputFile("result.txt");
  
  if(argc < 2)
  {
    printf("not enough args!\n");
    return 0;
  }
  
  int originSize = atoi(argv[1]);
  float sampleRatio = atof(argv[2]);

  printf("%d, %f\n", originSize, sampleRatio);
  
  pies test(inputFile , originSize, sampleRatio , outputFile);
  
  test.process();//
  test.saveSampleGraph();//
 
  return 0;
}