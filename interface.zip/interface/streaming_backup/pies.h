#include "stdafx.h"

#define MAX_FORBIDDEN_STACK_SIZE 2

using namespace std;

class pies
{
public:
  pies(string inFile , int originSize, float sampleRatio , string outFile);
	~pies(void);

	string inputFile;
	string outputFile;   	
  int size;
  float ratio;
  	
	map<int64_t,int> VSdegree;
	map<int,int> degreeMap;
	multimap<int64_t,int64_t> ES;

  void delEdge_process(string line, int *t);
  void addEdge_process(string line, int *t);
	void process();
 
	void updateDegreeMap(int , int);
	void dropNode();

	void delEdge(int64_t);
	void saveSampleGraph();
 
  void seekZeroDegreeNode();
  
  bool isInForbiddenStack(int64_t node); //ture: node is in forbidden stack  false: node is not in forbidden stack
  
private:

  int64_t forbidden_stack[MAX_FORBIDDEN_STACK_SIZE];
  int top_forbidden_stack;
  
  
  
};