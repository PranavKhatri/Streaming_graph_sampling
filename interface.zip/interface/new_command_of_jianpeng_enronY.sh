# add pies_random and advanced
# for k in $( seq 0 4 )
# do
# 	for s in $( seq 0.2 0.2 0.8)
# 	do
# ##### enronY 
#     ./pies_new 151 ${s} ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronY_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_enronY_result_${k}/
#    ./pies_old 151 ${s}  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronY_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_enronY_result_${k}/
#    ./pies_isolated_first 151 ${s}  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronY_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_enronY_result_${k}/
#    ./streamNS 151 ${s}  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronY_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_enronY_result_${k}/
#    ./streamES 151 ${s}  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronY_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_enronY_result_${k}/
#    ./pies_random 151 ${s} ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronY_u_45/collection.graph ../powlaw_degree_benchmark_results/random_pies_enronY_result_${k}/
# #   ./pies_advanced 151 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronY_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_enronY_result_${k}/
# 	done
# done
#
#
###### Note that the dataset name have suffix YY. 
######for normalized graph, for the paper testing the complete graph performance.
for k in $( seq 0 4 )
do
	for s in $( seq 0.2 0.2 0.8)
	do
##### enronY 
   ./pies_new 151 ${s} ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronYY_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_enronYY_result_${k}/
   ./pies_old 151 ${s}  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronYY_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_enronYY_result_${k}/
   ./pies_isolated_first 151 ${s}  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronYY_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_enronYY_result_${k}/
   ./streamNS 151 ${s}  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronYY_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_enronYY_result_${k}/
   ./streamES 151 ${s}  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronYY_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_enronYY_result_${k}/
   ./pies_random 151 ${s} ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronYY_u_45/collection.graph ../powlaw_degree_benchmark_results/random_pies_enronYY_result_${k}/
   ./pies_min 151 ${s} ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronYY_u_45/collection.graph ../powlaw_degree_benchmark_results/min_pies_enronYY_result_${k}/
#   ./pies_advanced 151 ${s} ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronYY_u_45/collection.graph ../powlaw_degree_benchmark_results/advanced_pies_enronY_result_${k}/
	done
done


# ./pies_old 151 0.2  ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_enronYY_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_enronYY_result_1/
