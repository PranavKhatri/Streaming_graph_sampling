#include "stdafx.h"
#include "stdio.h"
#include "streamES.h"
#include "time.h"

#include "string.h"
#include <sys/stat.h>
#include <sys/types.h>

streamES::streamES(string inFile , int originSize, float sampleRatio , string outFile)
{
	inputFile = inFile;
  ratio = sampleRatio;
	size = (int)(originSize * sampleRatio);
	outputFile = outFile;
}

streamES::~streamES()
{
}

void streamES::delEdge_process(string line, int salt)
{
  char symbol = ' ';
  int64_t from=0;
	int64_t to=0;
 
  sscanf(line.c_str(),"%c %ld %ld",&symbol,&from,&to);
  
  map< uint64_t, map<uint64_t,uint64_t> >::const_iterator it;
  int flag = 0;

	for ( it = EShash.begin(); it !=EShash.end() ; it++ )
	{
		if( ((it->second.begin()->first) == from) && ((it->second.begin()->second) == to))
    {
      EShash.erase(it->first);
      break;
    }
	}
 
  if ( it == EShash.end())
  {
    return;
  }
  
  map<uint64_t,int>::iterator fromVSdegree = VSdegree.find(from);
  map<uint64_t,int>::iterator toVSdegree =  VSdegree.find(to);  
  
  if(fromVSdegree != VSdegree.end())
  {
    VSdegree[from]--;
    if(VSdegree[from] == 0)
    {
      VSdegree.erase(fromVSdegree);
    }
  }
  if(toVSdegree != VSdegree.end())
  {
    VSdegree[to]--;
    if(VSdegree[to] == 0)
    {
      VSdegree.erase(toVSdegree);
    }
  }
}

void streamES::addEdge_process(string line, int salt)
{

  uint64_t from,to;
	uint64_t edgeHash;
	uint64_t max=0;
 
  sscanf(line.c_str(),"%ld %ld",&from,&to);
	edgeHash=hash64( from , to , salt);
	
  //printf("edgehash = %ld\n", edgeHash);
  
  
	if ( VSdegree.size()<size )
	{
	  if ( EShash.find(edgeHash) == EShash.end() )
	  {
			map<uint64_t,uint64_t> edge;
			//edge.insert(pair<uint64_t,uint64_t>(from,to));
			edge.insert(make_pair(from, to));
      //EShash.insert(pair<uint64_t,map<uint64_t,uint64_t>>(edgeHash,edge));
      EShash.insert(make_pair(edgeHash, edge));
        

      if( VSdegree.find(from) == VSdegree.end() )
        VSdegree.insert( pair<uint64_t,uint64_t>(from,1) );
      else
        VSdegree[from]++;

      if( VSdegree.find(to) == VSdegree.end() )
        VSdegree.insert( pair<uint64_t,uint64_t>(to,1) );
      else
        VSdegree[to]++;
    }
  }
  else
  {
    //cout << EShash.size()<<"  "<<VSdegree.size()<<endl;

    max = EShash.rbegin()->first;

    if( edgeHash < max && EShash.find(edgeHash) == EShash.end() )
    {
    
      map<uint64_t,uint64_t> edge;
      //edge.insert(pair<uint64_t,uint64_t>(from,to));
      edge.insert(make_pair(from, to));	
      //EShash.insert(pair<uint64_t,map<uint64_t,uint64_t>>(edgeHash,edge));
      EShash.insert(make_pair(edgeHash, edge));

      if( VSdegree.find(from) == VSdegree.end() )
        VSdegree.insert( pair<uint64_t,uint64_t>(from,1) );
      else
        VSdegree[from]++;

      if( VSdegree.find(to) == VSdegree.end() )
        VSdegree.insert( pair<uint64_t,uint64_t>(to,1) );
      else    
        VSdegree[to]++;

      delEdge();
    }
  }
  
}

void streamES::process()
{
	ifstream ifs(inputFile.c_str());
	if( !ifs.is_open() )
	{
		cout<<"Error opening file";
		exit(1);
	}

	cout<<"sampling......"<<endl;
	
	string line;
	uint64_t from,to;
	uint64_t edgeHash;
	uint64_t max=0;

	time_t timep;
	int salt = time(&timep);

  int t = 0;
  
	while ( getline( ifs,line ) )
	{
    //printf("t = %d\n", t);
    //t = t + 1;
    
    //printf("%s\n", line.c_str());
    
    if((line[0] >= '0') && (line[0] <= '9'))
    {
       addEdge_process(line, salt);
       //cout<<"VS COUNT: "<<VSdegree.size()<< "  " << " ES COUNT: "<<EShash.size()<<endl;
    }
    else if(line[0] == '!')
    {
       delEdge_process(line, salt);
       //cout<<"VS COUNT: "<<VSdegree.size()<< "  " << " ES COUNT: "<<EShash.size()<<endl;
    }
    else
    {
      string filename(line);          
//      char snapshot_dir[128] = "../old_pies_merge_result/";
      char snapshot_dir[128] = "";
      strcpy(snapshot_dir, outputFile.c_str());

      if (access(snapshot_dir,6)==-1)
      {
          mkdir(snapshot_dir, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
      }
      
      printf("my snapshot_dir %s: \n", snapshot_dir);
      
      char buf[16];
      sprintf(buf, "%f", ratio);
      strcat(snapshot_dir, buf);
      strcat(snapshot_dir, "/");
      if (access(snapshot_dir, 6)==-1)
      {
      	  mkdir(snapshot_dir, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
          printf("create!\n");
      }
      
      
       string dir(snapshot_dir);    
       string filepath = dir + filename;
      
       int i;
       
       cout << "snapshot " << filepath << " is completed" << endl;
	     cout<<"VS COUNT: "<<VSdegree.size()<<"\t"<<" ES COUNT: "<<EShash.size()<<endl;            
       
       
       ofstream out(filepath.c_str());
	     if ( ! out.is_open() )
	     {
		      cout<<"Error opening file"<<endl;
		      exit(1);
	     }

       map< uint64_t, map<uint64_t,uint64_t> >::const_iterator it;
	     for ( it = EShash.begin(); it != EShash.end() ; it++ )
	     {
          if ((it->second.begin()->first) < (it->second.begin()->second))
          {
            out<<it->second.begin()->first<<"\t"<<it->second.begin()->second<<endl;
          }
          if ((it->second.begin()->first) == (it->second.begin()->second))
          {
            //printf("impossible!\n");
          }
	     }
       out.close();
       
    }
    
    //printf("VS size = %d\n", VSdegree.size());
    //printf("ES size = %d\n", EShash.size());
	}
}

uint64_t streamES::hash64( uint64_t a , uint64_t b , int salt )
{
  //printf("a = %d, b = %d, salt = %d\n", a, b, salt);
  
	a = (~a) + ( a << 21 ) + salt;
	b = (~b) + ( b << 21 ) + salt;

	a = a ^ ( a >> 24 );
	b = b ^ ( b >> 24 );

	a = ( a + ( a << 3 ) ) + ( a << 8 );
	b = ( b + ( b << 3 ) ) + ( b << 8 );

	a = a ^ ( a >> 14 );
	b = b ^ ( b >> 14 );

	a = ( a + ( a << 2 ) ) + ( a << 4 );
	b = ( b + ( b << 2 ) ) + ( b << 4 );

	a = a ^ ( a >> 28 );
	b = b ^ ( b >> 28 );

	a = a + ( a << 31 );
	b = b + ( b << 31 );

  //printf("a' = %d, b' = %d\n", a, b);
  
	return a+b;
}

void streamES::delEdge()
{
	uint64_t max=0;	
	uint64_t from,to = 0;
	
	//cout<<EShash.size()<<"  "<<VSdegree.size()<<endl;

	while ( VSdegree.size() > size )
	{
		max = EShash.rbegin()->first;
		if ( EShash.find(max) != EShash.end() )
		{
			from = EShash[max].begin() -> first;
			to = EShash[max].begin() -> second;

			EShash.erase( max );

			if ( VSdegree.find(from) != VSdegree.end() )
				(VSdegree[from]>1) ? (VSdegree[from]--) : (VSdegree.erase(from));

			if ( VSdegree.find(to) != VSdegree.end() )
				(VSdegree[to]>1) ? ( VSdegree[to]--) : (VSdegree.erase(to));
		}
	}

	//cout<<EShash.size()<<"  "<<VSdegree.size()<<endl;

}

void streamES::saveSampleGraph()
{
	cout<<"VS COUNT: "<<VSdegree.size()<<" ES COUNT: "<<EShash.size()<<endl;

	map< uint64_t, map<uint64_t,uint64_t> >::const_iterator it;
	ofstream out(outputFile.c_str());
	if ( ! out.is_open() )
	{
		cout << "Error opening file"<<endl;
		exit(1);
	}

	for ( it = EShash.begin(); it !=EShash.end() ; it++ )
	{
		out<<it->second.begin()->first<<" "<<it->second.begin()->second<<endl;
	}

	out.close();

}
		
int main(int argc, char* argv[])
{
	if(argc < 4)
  {
    printf("not enough args!\n");
    return 0;
  }
  //string inputFile("../original_snapshot_20w/collection.graph");
  //string outputFile("result.txt"); that's for the saveSampleGraph function
  //char snapshot_dir[128] = "../old_pies_snapshot/";
  string inputFile = argv[3];
	string outputFile = argv[4];
  
  int originSize = atoi(argv[1]);
  float sampleRatio = atof(argv[2]);
  
  printf("%d, %f\n", originSize, sampleRatio);

  //test the time usage
  clock_t start,finish;
  double totaltime;
  start=clock();
  streamES test(inputFile , originSize, sampleRatio , outputFile);
  test.process();//

  //end the time usage
  finish=clock();
  totaltime=(double)(finish-start)/CLOCKS_PER_SEC;
  cout<< inputFile <<"StreamES time usage is : "<<totaltime<<"(s)"<<endl;

  string filename = "StreamES_timeusage.txt";
  ofstream time_output(filename.c_str());
  if (! time_output.is_open() )
  {
    cout<<"Error opening file"<<endl;
    exit(1);
  }
  time_output<<inputFile <<", "<<"StreamES,"<< totaltime <<"(s)\n"<<endl;
  time_output.close();

//  test.saveSampleGraph();//
 
  return 0;
}