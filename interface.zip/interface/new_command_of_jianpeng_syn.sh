for k in $( seq 0 4 )
do
#### synthetic_graph new_mergesplit_1000_u_20
	./pies_new 1000 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_mergesplit_1000_u_20/collection.graph ../powlaw_degree_benchmark_results/new_pies_mergesplit_1000_result_${k}/
	./pies_old 1000 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_mergesplit_1000_u_20/collection.graph ../powlaw_degree_benchmark_results/old_pies_mergesplit_1000_result_${k}/
	./pies_isolated_first 1000 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_mergesplit_1000_u_20/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_mergesplit_1000_result_${k}/
	./streamNS 1000 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_mergesplit_1000_u_20/collection.graph ../powlaw_degree_benchmark_results/streamNS_mergesplit_1000_result_${k}/
	./streamES 1000 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_mergesplit_1000_u_20/collection.graph ../powlaw_degree_benchmark_results/streamES_mergesplit_1000_result_${k}/
	./pies_advanced 1000 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_mergesplit_1000_u_20/collection.graph ../powlaw_degree_benchmark_results/pies_advanced_mergesplit_1000_result_${k}/
	#### synthetic_graph new_expand_1000_u_20
	./pies_new 1000 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_expand_1000_u_20/collection.graph ../powlaw_degree_benchmark_results/new_pies_expand_1000_result_${k}/
	./pies_old 1000 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_expand_1000_u_20/collection.graph ../powlaw_degree_benchmark_results/old_pies_expand_1000_result_${k}/
	./pies_isolated_first 1000 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_expand_1000_u_20/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_expand_1000_result_${k}/
	./streamNS 1000 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_expand_1000_u_20/collection.graph ../powlaw_degree_benchmark_results/streamNS_expand_1000_result_${k}/
	./streamES 1000 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_expand_1000_u_20/collection.graph ../powlaw_degree_benchmark_results/streamES_expand_1000_result_${k}/
	./pies_advanced 1000 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_expand_1000_u_20/collection.graph ../powlaw_degree_benchmark_results/pies_advanced_expand_1000_result_${k}/
done
#
#
# ##### synthetic_graph new_mergesplit_128_u_45
# ./pies_new 128 0.5 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_mergesplit_128_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_mergesplit_128_result/
# ./pies_old 128 0.5 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_mergesplit_128_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_mergesplit_128_result/
# ./pies_isolated_first 128 0.5 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_mergesplit_128_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_mergesplit_128_result/
# ./streamNS 128 0.5 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_mergesplit_128_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_mergesplit_128_result/
# ./streamES 128 0.5 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_mergesplit_128_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_mergesplit_128_result/
# ./pies_advanced 1000 0.2 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_mergesplit_128_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_advanced_mergesplit_128_result/
# ##### synthetic_graph new_expand_1000_u_20
# ./pies_new 128 0.5 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_expand_128_u_45/collection.graph ../powlaw_degree_benchmark_results/new_pies_expand_128_result/
# ./pies_old 128 0.5 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_expand_128_u_45/collection.graph ../powlaw_degree_benchmark_results/old_pies_expand_128_result/
# ./pies_isolated_first 128 0.5 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_expand_128_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_isolated_first_expand_128_result/
# ./streamNS 128 0.5 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_expand_128_u_45/collection.graph ../powlaw_degree_benchmark_results/streamNS_expand_128_result/
# ./streamES 128 0.5 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_expand_128_u_45/collection.graph ../powlaw_degree_benchmark_results/streamES_expand_128_result/
# ./pies_advanced 128 0.5 ../powlaw_degree_small_snapshot_graph_for_streaming_sampling/new_expand_128_u_45/collection.graph ../powlaw_degree_benchmark_results/pies_advanced_expand_128_result/
