'''
Created on Jun 22, 2013

@author: Emrah Cem{emrah.cem@utdallas.edu}
'''

__all__=['load_experiment']
    
def load_experiment(exp, exp_loader):
    exp_loader.load_experiment(exp)